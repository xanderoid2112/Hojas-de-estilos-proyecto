document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.getElementById('menu-toggle');
    const nav = document.querySelector('nav');
    const menuLinks = document.querySelectorAll('.menu a');

    // Mostrar/ocultar menú al hacer clic en el checkbox
    menuToggle.addEventListener('change', () => {
        nav.classList.toggle('show', menuToggle.checked);
    });

    // Cerrar menú al hacer clic en un enlace
    menuLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (menuToggle.checked) {
                menuToggle.checked = false;
                nav.classList.remove('show');
            }
        });
    });
});

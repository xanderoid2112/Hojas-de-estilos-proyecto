//funcion cerrar menú hamburguesa
document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.getElementById('menu-toggle');
    const menuLinks = document.querySelectorAll('.menu a');

    menuLinks.forEach(link => {
        link.addEventListener('click', () => {
            // Si el menú hamburguesa está abierto, lo cerramos
            if (menuToggle.checked) {
                menuToggle.checked = false;
            }
        });
    });
});